"""Interface Streamlit — Tob e Lucas Shorts.  Rodar com:  streamlit run app.py"""

import os
from datetime import datetime
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

ROOT = Path(__file__).parent
load_dotenv(ROOT / ".env")

from src import store  # noqa: E402
from src.montage import concat_clips, have_ffmpeg, is_vertical_9_16, probe  # noqa: E402
from src.prompt_builder import CAMERA_OPTIONS, build_prompt  # noqa: E402
from src.providers.base import ClipRequest, ProviderError, ProviderNotConfigured  # noqa: E402
from src.providers.fal_kling import DEFAULT_MODEL, MODELS, FalKling, estimate_cost  # noqa: E402

ASSETS = ROOT / "assets" / "personagens"
OUTPUT = ROOT / "output"
SCENES_FILE = OUTPUT / "scenes.json"
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
VIDEO_EXTS = ["mp4", "mov", "webm"]

MODE_FLOW = "Flow (manual)"
MODE_FAL = "fal.ai · Kling (automático)"
FLOW_DURATIONS = [4, 6, 8]  # durações do Veo; confira as opções reais no Flow

st.set_page_config(page_title="Tob e Lucas Shorts", page_icon="🎬", layout="centered")

if "scenes" not in st.session_state:
    st.session_state.scenes = store.load(SCENES_FILE)
scenes: list[dict] = st.session_state.scenes


def persist():
    store.save(scenes, SCENES_FILE)


def list_images() -> list[Path]:
    if not ASSETS.exists():
        return []
    return sorted(p for p in ASSETS.iterdir() if p.suffix.lower() in IMAGE_EXTS)


def attach_video(scene: dict, path: Path, model: str) -> None:
    """Associa um arquivo de vídeo à cena (apaga o anterior se o nome mudou)."""
    old = ROOT / scene["video"] if scene.get("video") else None
    if old and old.exists() and old != path:
        old.unlink()
    scene.update(
        status="gerada", video=str(path.relative_to(ROOT)), model=model, error=None,
        info=probe(path),
    )


def save_uploaded(scene: dict, uploaded) -> None:
    """Salva o clipe baixado do Flow na pasta output/ e valida que é um vídeo."""
    suffix = Path(uploaded.name).suffix.lower() or ".mp4"
    out_path = OUTPUT / f"{scene['character']}_{scene['id']}{suffix}"
    OUTPUT.mkdir(parents=True, exist_ok=True)
    tmp = out_path.with_suffix(".upload")
    tmp.write_bytes(uploaded.getbuffer())
    if have_ffmpeg() and probe(tmp) is None:
        tmp.unlink()
        scene.update(error="Esse arquivo não parece ser um vídeo válido. Baixe o clipe de novo no Flow.")
        persist()
        return
    tmp.replace(out_path)
    attach_video(scene, out_path, "flow-manual")
    persist()


def generate(scene: dict, model_key: str) -> None:
    """Gera o clipe via fal.ai. Nunca simula: sem chave, mostra erro e para."""
    image_path = ROOT / scene["image"]
    if not image_path.exists():
        scene.update(status="erro", error=f"Imagem não encontrada: {scene['image']}")
        persist()
        return
    out_path = OUTPUT / f"{scene['character']}_{scene['id']}.mp4"
    provider = FalKling(model_key)
    with st.status(f"Gerando cena {scene['id']}...", expanded=True) as status_box:
        try:
            provider.generate(
                ClipRequest(image_path, scene["prompt"], scene["duration"]),
                out_path,
                on_status=lambda msg: status_box.write(msg),
            )
            attach_video(scene, out_path, model_key)
            status_box.update(label="Clipe gerado", state="complete")
        except ProviderNotConfigured as e:
            status_box.update(label="Serviço não conectado", state="error")
            st.error(str(e))
        except ProviderError as e:
            scene.update(status="erro", error=str(e))
            status_box.update(label="Falha na geração", state="error")
            st.error(str(e))
    persist()


# ---------------------------------------------------------------- barra lateral
with st.sidebar:
    st.header("Como gerar os clipes")
    mode = st.radio("Modo", [MODE_FLOW, MODE_FAL], label_visibility="collapsed")
    model_key = DEFAULT_MODEL
    if mode == MODE_FAL:
        model_key = st.selectbox(
            "Modelo",
            list(MODELS),
            index=list(MODELS).index(DEFAULT_MODEL),
            format_func=lambda k: MODELS[k]["label"],
        )
        if os.getenv("FAL_KEY"):
            st.success("FAL_KEY encontrada")
        else:
            st.warning("FAL_KEY não configurada. Copie .env.example para .env e cole sua chave.")
        st.caption("Custos são estimativas; confira em fal.ai/pricing. Cada geração é cobrada.")
    else:
        st.caption("Você gera cada clipe no site do Flow e envia o vídeo para a cena. O app prepara os "
                   "prompts, guarda a ordem e junta tudo no final.")
    if not have_ffmpeg():
        st.warning("ffmpeg/ffprobe não encontrados: não dá para validar clipes nem juntar o vídeo final aqui.")

FLOW = mode == MODE_FLOW
durations = FLOW_DURATIONS if FLOW else MODELS[model_key]["durations"]

st.title("🎬 Tob e Lucas Shorts")
tab_new, tab_scenes, tab_final = st.tabs(["1. Nova cena", "2. Cenas e clipes", "3. Montagem"])

# ---------------------------------------------------------------- nova cena
with tab_new:
    images = list_images()
    if not images:
        st.info(f"Coloque as imagens dos personagens em `{ASSETS.relative_to(ROOT)}/`.")
    else:
        chosen = st.selectbox("Personagem (imagem original)", images, format_func=lambda p: p.stem)
        st.image(str(chosen), width=180)
        with st.form("nova_cena", clear_on_submit=False):
            action = st.text_area(
                "Ação principal *",
                placeholder="Ex.: o Tob corre em círculos e depois senta, balançando o rabo",
            )
            body = st.text_input("Movimento do corpo", placeholder="Ex.: pula de alegria, balança as orelhas")
            expression = st.text_input("Expressão facial", placeholder="Ex.: sorriso grande, olhos arregalados")
            camera = st.selectbox("Câmera", list(CAMERA_OPTIONS))
            scenario = st.text_input(
                "Cenário",
                placeholder="Ex.: sala de estar ensolarada",
                help="A imagem original fixa o primeiro quadro. O cenário descrito evolui a partir dele; "
                "para um cenário totalmente diferente, use outra imagem base.",
            )
            if len(durations) > 3:
                duration = st.slider("Duração (s)", durations[0], durations[-1], 5)
            else:
                duration = st.radio("Duração desejada (s)", durations, index=len(durations) - 1,
                                    horizontal=True)
            if FLOW:
                st.caption("Confira no Flow quais durações estão disponíveis; este valor é só uma anotação.")
            else:
                st.caption(f"Custo estimado: ~US$ {estimate_cost(model_key, duration):.2f}")
            submitted = st.form_submit_button("Adicionar à lista de cenas")
        if submitted:
            try:
                prompt = build_prompt(action, body, expression, camera, scenario)
            except ValueError as e:
                st.error(str(e))
            else:
                scenes.append(
                    store.new_scene(
                        character=chosen.stem,
                        image=str(chosen.relative_to(ROOT)),
                        fields=dict(action=action, body=body, expression=expression,
                                    camera=camera, scenario=scenario),
                        prompt=prompt,
                        duration=int(duration),
                    )
                )
                persist()
                st.success("Cena adicionada. Vá para a aba 2.")

# ---------------------------------------------------------------- cenas
with tab_scenes:
    if not scenes:
        st.info("Nenhuma cena ainda. Crie uma na aba 1.")
    else:
        done = sum(1 for s in scenes if s["status"] == "gerada")
        st.caption(f"{len(scenes)} cenas · {done} com clipe")

        if FLOW:
            with st.expander("Como usar no Flow"):
                st.markdown(
                    "1. Abra o Flow e um projeto.\n"
                    "2. No campo de prompt, escolha **Video → Frames** e arraste a imagem da cena para "
                    "**Add start frame** (assim o personagem sai idêntico à imagem original).\n"
                    "3. Escolha o formato da imagem. Para Shorts precisa ser vertical (9:16); a ajuda do "
                    "Flow não lista os formatos, então confira se essa opção existe na sua conta.\n"
                    "4. Cole o prompt da cena e clique em **Generate**.\n"
                    "5. Baixe o melhor resultado e envie aqui, no campo da cena.\n\n"
                    "Os nomes dos menus podem mudar. Gerar vídeo gasta créditos da sua assinatura do Flow."
                )
            script = "\n\n".join(
                f"CENA {i + 1} · {s['character']} · {s['duration']} s · imagem: {Path(s['image']).name}\n"
                f"{s['prompt']}"
                for i, s in enumerate(scenes)
            )
            with st.expander("Roteiro completo (todas as cenas, para copiar)"):
                st.code(script, language=None)
        else:
            pending = [s for s in scenes if s["status"] != "gerada"]
            total = sum(estimate_cost(model_key, s["duration"]) for s in pending
                        if s["duration"] in MODELS[model_key]["durations"])
            st.caption(f"{len(pending)} para gerar · custo estimado ~US$ {total:.2f}")
            if pending and st.button("Gerar todas as pendentes", type="primary"):
                for s in pending:
                    generate(s, model_key)
                st.rerun()

        for i, s in enumerate(scenes):
            with st.container(border=True):
                head, b_up, b_down, b_del = st.columns([6, 1, 1, 1])
                head.markdown(f"**Cena {i + 1}** · {s['character']} · {s['duration']} s · `{s['status']}`")
                if b_up.button("⬆", key=f"up{s['id']}"):
                    store.move(scenes, i, -1); persist(); st.rerun()
                if b_down.button("⬇", key=f"dn{s['id']}"):
                    store.move(scenes, i, +1); persist(); st.rerun()
                if b_del.button("🗑", key=f"rm{s['id']}"):
                    store.delete(scenes, i); persist(); st.rerun()

                st.write(s["fields"]["action"])
                if FLOW:
                    thumb, txt = st.columns([1, 3])
                    thumb.image(str(ROOT / s["image"]), width=90)
                    txt.caption(f"Imagem inicial: `{s['image']}`")
                    txt.code(s["prompt"], language=None)  # o botão de copiar já vem no bloco
                else:
                    with st.expander("Prompt enviado"):
                        st.code(s["prompt"], language=None)

                if s["error"]:
                    st.error(s["error"])
                video = ROOT / s["video"] if s["video"] else None
                if video and video.exists():
                    st.video(str(video))
                    info = s.get("info")
                    if info and not is_vertical_9_16(info):
                        st.warning(
                            f"Este clipe é {info['width']}x{info['height']}, não vertical 9:16. "
                            "No vídeo final ele ficaria com barras pretas. Gere de novo em formato vertical."
                        )

                if FLOW:
                    up = st.file_uploader("Clipe baixado do Flow", type=VIDEO_EXTS, key=f"file{s['id']}")
                    if up is not None and st.button("Salvar clipe nesta cena", key=f"save{s['id']}"):
                        save_uploaded(s, up)
                        st.rerun()
                else:
                    label = "Gerar novamente" if s["status"] == "gerada" else "Gerar esta cena"
                    if st.button(label, key=f"gen{s['id']}"):
                        generate(s, model_key)
                        st.rerun()

# ---------------------------------------------------------------- montagem
with tab_final:
    ready = [ROOT / s["video"] for s in scenes if s["status"] == "gerada" and s["video"]
             and (ROOT / s["video"]).exists()]
    if not ready:
        st.info("Adicione pelo menos um clipe a uma cena para montar o vídeo final.")
    else:
        st.write(f"{len(ready)} clipes, na ordem da aba 2.")
        st.caption("Cada clipe é ajustado para 1080x1920 e 30 fps; clipes sem áudio ganham trilha silenciosa.")
        if st.button("Juntar em um único vídeo"):
            try:
                with st.spinner("Juntando clipes..."):
                    final = concat_clips(ready, OUTPUT / f"short_final_{datetime.now():%Y%m%d_%H%M%S}.mp4")
                st.success(f"Salvo em {final.relative_to(ROOT)}")
                st.video(str(final))
            except (RuntimeError, ValueError) as e:
                st.error(str(e))
