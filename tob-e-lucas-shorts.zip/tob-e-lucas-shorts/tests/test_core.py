import pytest

from src import store
from src.prompt_builder import CAMERA_OPTIONS, CONSISTENCY_SUFFIX, build_prompt
from src.providers.base import ClipRequest, ProviderError, ProviderNotConfigured
from src.providers.fal_kling import FalKling, build_arguments, estimate_cost


def test_prompt_contains_fields_and_consistency():
    p = build_prompt("corre em círculos", "balança o rabo", "sorriso", "Zoom in lento", "sala")
    for piece in ["corre em círculos", "balança o rabo", "sorriso", "sala", "push-in", CONSISTENCY_SUFFIX]:
        assert piece in p


def test_prompt_requires_action_and_valid_camera():
    with pytest.raises(ValueError):
        build_prompt("   ")
    with pytest.raises(ValueError):
        build_prompt("pula", camera="inexistente")
    assert all(build_prompt("pula", camera=c) for c in CAMERA_OPTIONS)


def test_arguments_v3():
    a = build_arguments("kling-v3-standard", "https://x/img.png", "p", 7)
    assert a == {"prompt": "p", "start_image_url": "https://x/img.png", "duration": "7", "aspect_ratio": "9:16"}


def test_arguments_v21_has_negative_prompt_and_no_aspect():
    a = build_arguments("kling-v2.1-standard", "https://x/img.png", "p", 5)
    assert a["image_url"] == "https://x/img.png" and "negative_prompt" in a and "aspect_ratio" not in a


def test_invalid_duration_rejected():
    with pytest.raises(ProviderError):
        build_arguments("kling-v2.1-standard", "u", "p", 7)
    with pytest.raises(ProviderError):
        build_arguments("kling-v3-standard", "u", "p", 20)


def test_cost_estimates():
    assert estimate_cost("kling-v2.1-standard", 5) == pytest.approx(0.25)
    assert estimate_cost("kling-v2.1-standard", 10) == pytest.approx(0.50)
    assert estimate_cost("kling-v3-standard", 5) == pytest.approx(0.42)


def test_without_key_raises_and_never_fakes(monkeypatch, tmp_path):
    monkeypatch.delenv("FAL_KEY", raising=False)
    img = tmp_path / "a.png"
    img.write_bytes(b"x")
    out = tmp_path / "out.mp4"
    with pytest.raises(ProviderNotConfigured):
        FalKling().generate(ClipRequest(img, "p", 5), out)
    assert not out.exists()


def test_store_roundtrip_move_delete(tmp_path):
    f = tmp_path / "scenes.json"
    scenes = [store.new_scene("tob", "a.png", {}, "p1", 5), store.new_scene("lucas", "b.png", {}, "p2", 5)]
    store.move(scenes, 1, -1)
    assert [s["character"] for s in scenes] == ["lucas", "tob"]
    store.move(scenes, 0, -1)  # fora do limite: não faz nada
    assert scenes[0]["character"] == "lucas"
    store.save(scenes, f)
    assert store.load(f) == scenes
    store.delete(scenes, 0)
    assert len(scenes) == 1


def test_corrupted_store_is_kept_not_deleted(tmp_path):
    f = tmp_path / "scenes.json"
    f.write_text("{ quebrado", encoding="utf-8")
    assert store.load(f) == []
    assert any("corrompido" in p.name for p in tmp_path.iterdir())
