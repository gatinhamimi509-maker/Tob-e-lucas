import shutil
import subprocess

import pytest

from src.montage import concat_clips, is_vertical_9_16, probe

pytestmark = pytest.mark.skipif(
    not (shutil.which("ffmpeg") and shutil.which("ffprobe")), reason="ffmpeg/ffprobe ausentes"
)


def _clip(path, size, color, audio):
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"color=c={color}:s={size}:d=1:r=24"]
    if audio:
        cmd += ["-f", "lavfi", "-i", "sine=frequency=440:duration=1"]
    subprocess.run(cmd + ["-pix_fmt", "yuv420p", "-shortest", str(path)], check=True)


def test_probe_and_vertical_check(tmp_path):
    v, h = tmp_path / "v.mp4", tmp_path / "h.mp4"
    _clip(v, "720x1280", "red", True)
    _clip(h, "1280x720", "green", False)
    assert is_vertical_9_16(probe(v)) and probe(v)["has_audio"]
    assert not is_vertical_9_16(probe(h)) and not probe(h)["has_audio"]


def test_invalid_file_is_not_a_video(tmp_path):
    fake = tmp_path / "fake.mp4"
    fake.write_bytes(b"nao e video")
    assert probe(fake) is None
    with pytest.raises(RuntimeError):
        concat_clips([fake], tmp_path / "out.mp4")


def test_concat_mixed_clips_is_normalized(tmp_path):
    a, b = tmp_path / "a.mp4", tmp_path / "b.mp4"
    _clip(a, "720x1280", "red", True)      # com áudio
    _clip(b, "1080x1920", "blue", False)   # sem áudio
    info = probe(concat_clips([a, b], tmp_path / "final.mp4"))
    assert (info["width"], info["height"]) == (1080, 1920)
    assert info["has_audio"] and 1.8 < info["duration"] < 2.3
