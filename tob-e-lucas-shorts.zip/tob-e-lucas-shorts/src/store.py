"""Lista de cenas salva em output/scenes.json (ordem da lista = ordem do Short)."""

from __future__ import annotations

import json
import uuid
from datetime import datetime
from pathlib import Path


def load(path: Path) -> list[dict]:
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        # Não apaga nada: guarda o arquivo ruim e começa uma lista nova.
        path.rename(path.with_suffix(f".corrompido-{datetime.now():%H%M%S}.json"))
        return []


def save(scenes: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(scenes, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def new_scene(character: str, image: str, fields: dict, prompt: str, duration: int) -> dict:
    return {
        "id": uuid.uuid4().hex[:8],
        "character": character,
        "image": image,
        "fields": fields,
        "prompt": prompt,
        "duration": duration,
        "status": "pendente",  # pendente | gerada | erro
        "video": None,
        "model": None,
        "error": None,
        "created": datetime.now().isoformat(timespec="seconds"),
    }


def move(scenes: list[dict], index: int, delta: int) -> None:
    target = index + delta
    if 0 <= target < len(scenes):
        scenes[index], scenes[target] = scenes[target], scenes[index]


def delete(scenes: list[dict], index: int) -> None:
    del scenes[index]
