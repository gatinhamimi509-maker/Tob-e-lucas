"""Kling image-to-video via fal.ai.

Endpoints e nomes de parâmetros conferidos na documentação oficial da fal
(fal.ai/docs/model-api-reference/video-generation-api) em 15/10/2026.
Chave: variável de ambiente FAL_KEY (lida pelo próprio fal_client).
"""

from __future__ import annotations

import os
import urllib.request
from pathlib import Path
from typing import Callable, Optional

from ..prompt_builder import NEGATIVE_PROMPT
from .base import (
    ClipRequest,
    ClipResult,
    Provider,
    ProviderError,
    ProviderNotConfigured,
)

MODELS = {
    "kling-v3-standard": {
        "label": "Kling 3.0 Standard (recomendado)",
        "endpoint": "fal-ai/kling-video/v3/standard/image-to-video",
        "image_field": "start_image_url",
        "durations": list(range(3, 16)),
        "supports_aspect_ratio": True,
        "supports_negative_prompt": False,
        # Estimativa vinda de comparativos de terceiros; confira em fal.ai/pricing.
        "base_seconds": 0,
        "base_usd": 0.0,
        "usd_per_extra_second": 0.084,
    },
    "kling-v2.1-standard": {
        "label": "Kling 2.1 Standard (mais barato, 5 ou 10 s)",
        "endpoint": "fal-ai/kling-video/v2.1/standard/image-to-video",
        "image_field": "image_url",
        "durations": [5, 10],
        "supports_aspect_ratio": False,  # a proporção segue a imagem (já é 9:16)
        "supports_negative_prompt": True,
        # Preço publicado na página do modelo: US$0,25 por 5 s + US$0,05 por segundo extra.
        "base_seconds": 5,
        "base_usd": 0.25,
        "usd_per_extra_second": 0.05,
    },
}

DEFAULT_MODEL = "kling-v3-standard"


def estimate_cost(model_key: str, duration: int) -> float:
    m = MODELS[model_key]
    return m["base_usd"] + m["usd_per_extra_second"] * max(0, duration - m["base_seconds"])


def build_arguments(
    model_key: str, image_url: str, prompt: str, duration: int, aspect_ratio: str = "9:16"
) -> dict:
    """Monta o corpo da requisição. Função pura (testável sem rede)."""
    m = MODELS[model_key]
    if duration not in m["durations"]:
        raise ProviderError(
            f"{m['label']} aceita duração de {m['durations'][0]} a {m['durations'][-1]} s "
            f"(valores: {m['durations']}). Pedido: {duration} s."
        )
    args = {
        "prompt": prompt,
        m["image_field"]: image_url,
        "duration": str(duration),
    }
    if m["supports_aspect_ratio"]:
        args["aspect_ratio"] = aspect_ratio
    if m["supports_negative_prompt"]:
        args["negative_prompt"] = NEGATIVE_PROMPT
    return args


NOT_CONFIGURED_HELP = (
    "Serviço de vídeo não conectado. Para conectar: "
    "1) crie uma conta em fal.ai e adicione créditos; "
    "2) gere uma chave em fal.ai/dashboard/keys; "
    "3) copie .env.example para .env e cole a chave em FAL_KEY=; "
    "4) reinicie o app."
)


class FalKling(Provider):
    def __init__(self, model_key: str = DEFAULT_MODEL):
        if model_key not in MODELS:
            raise ValueError(f"Modelo desconhecido: {model_key}")
        self.model_key = model_key
        self.cfg = MODELS[model_key]

    def _check_ready(self):
        if not os.getenv("FAL_KEY"):
            raise ProviderNotConfigured(NOT_CONFIGURED_HELP)
        try:
            import fal_client  # noqa: F401
        except ImportError as e:
            raise ProviderNotConfigured(
                "Biblioteca ausente. Rode: pip install -r requirements.txt"
            ) from e

    def generate(
        self,
        request: ClipRequest,
        out_path: Path,
        on_status: Optional[Callable[[str], None]] = None,
    ) -> ClipResult:
        self._check_ready()
        import fal_client

        say = on_status or (lambda _msg: None)
        try:
            say("Enviando imagem...")
            image_url = fal_client.upload_file(request.image_path)
            args = build_arguments(
                self.model_key,
                image_url,
                request.prompt,
                request.duration,
                request.aspect_ratio,
            )

            def on_update(update):
                if isinstance(update, fal_client.Queued):
                    say(f"Na fila (posição {update.position})...")
                elif isinstance(update, fal_client.InProgress):
                    say("Gerando vídeo...")

            result = fal_client.subscribe(
                self.cfg["endpoint"], arguments=args, on_queue_update=on_update
            )
        except fal_client.FalClientError as e:
            raise ProviderError(f"Erro da fal.ai: {e}") from e

        video = (result or {}).get("video") or {}
        url = video.get("url")
        if not url:
            raise ProviderError(f"A resposta não trouxe um vídeo: {result!r}")

        say("Baixando vídeo...")
        out_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = out_path.with_suffix(".part")
        try:
            with urllib.request.urlopen(url, timeout=120) as resp, open(tmp, "wb") as f:
                while chunk := resp.read(1 << 20):
                    f.write(chunk)
            tmp.replace(out_path)
        except OSError as e:
            tmp.unlink(missing_ok=True)
            raise ProviderError(f"Falha ao baixar o vídeo gerado: {e}") from e
        return ClipResult(video_url=url, local_path=out_path)
