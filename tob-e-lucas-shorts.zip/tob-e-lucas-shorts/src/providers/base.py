from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional


class ProviderError(Exception):
    """Falha ao gerar o clipe (rede, API, conteúdo recusado...)."""


class ProviderNotConfigured(ProviderError):
    """Serviço sem chave de API ou sem biblioteca instalada."""


@dataclass
class ClipRequest:
    image_path: Path
    prompt: str
    duration: int
    aspect_ratio: str = "9:16"


@dataclass
class ClipResult:
    video_url: str
    local_path: Path


class Provider(ABC):
    """Interface mínima. Para trocar de serviço, crie outro arquivo em
    src/providers/ com uma classe que implemente `generate`."""

    @abstractmethod
    def generate(
        self,
        request: ClipRequest,
        out_path: Path,
        on_status: Optional[Callable[[str], None]] = None,
    ) -> ClipResult: ...
