"""Inspeção e montagem de clipes (precisa de ffmpeg e ffprobe).

Os clipes podem vir de fontes diferentes (Flow, Kling...) com resolução, fps e
áudio diferentes. Antes de juntar, cada um é normalizado para 1080x1920, 30 fps,
com áudio (clipes sem áudio ganham uma trilha silenciosa).
"""

from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path

TARGET_W, TARGET_H, FPS = 1080, 1920, 30


def have_ffmpeg() -> bool:
    return bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def probe(path: Path) -> dict | None:
    """Devolve {width, height, duration, has_audio}, ou None se não for um vídeo válido
    (ou se o ffprobe não estiver instalado)."""
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return None
    proc = subprocess.run(
        [ffprobe, "-v", "error", "-show_entries",
         "stream=codec_type,width,height:format=duration", "-of", "json", str(path)],
        capture_output=True, text=True,
    )
    if proc.returncode != 0:
        return None
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return None
    streams = data.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"), None)
    if not video or not video.get("width") or not video.get("height"):
        return None
    try:
        duration = float(data.get("format", {}).get("duration"))
    except (TypeError, ValueError):
        duration = None
    return {
        "width": int(video["width"]),
        "height": int(video["height"]),
        "duration": duration,
        "has_audio": any(s.get("codec_type") == "audio" for s in streams),
    }


def is_vertical_9_16(info: dict, tolerance: float = 0.02) -> bool:
    return abs(info["width"] / info["height"] - 9 / 16) <= tolerance


def _run(cmd: list[str], what: str) -> None:
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg falhou ao {what}:\n{proc.stderr[-800:]}")


def concat_clips(clips: list[Path], out_path: Path) -> Path:
    if not have_ffmpeg():
        raise RuntimeError(
            "ffmpeg/ffprobe não encontrados. Instale (https://ffmpeg.org) "
            "ou junte os clipes no seu editor de vídeo."
        )
    if len(clips) < 1:
        raise ValueError("Nenhum clipe para juntar.")
    ffmpeg = shutil.which("ffmpeg")

    vf = (
        f"scale={TARGET_W}:{TARGET_H}:force_original_aspect_ratio=decrease,"
        f"pad={TARGET_W}:{TARGET_H}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={FPS},format=yuv420p"
    )
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        normalized = []
        for i, clip in enumerate(clips):
            info = probe(clip)
            if info is None:
                raise RuntimeError(f"'{Path(clip).name}' não é um vídeo válido.")
            n = tmp / f"n{i}.mp4"
            cmd = [ffmpeg, "-y", "-loglevel", "error", "-i", str(clip)]
            if not info["has_audio"]:
                cmd += ["-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000"]
            cmd += ["-vf", vf, "-map", "0:v:0", "-map", "0:a:0" if info["has_audio"] else "1:a:0",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                    "-c:a", "aac", "-ar", "48000", "-ac", "2", "-shortest", str(n)]
            _run(cmd, f"preparar '{Path(clip).name}'")
            normalized.append(n)

        list_file = tmp / "lista.txt"
        # Os arquivos normalizados ficam numa pasta temporária criada por nós (sem aspas no caminho).
        list_file.write_text("\n".join(f"file '{n}'" for n in normalized), encoding="utf-8")
        out_path.parent.mkdir(parents=True, exist_ok=True)
        _run([ffmpeg, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0",
              "-i", str(list_file), "-c", "copy", str(out_path)], "juntar os clipes")
    return out_path
