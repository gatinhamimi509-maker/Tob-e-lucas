"""Monta o prompt de movimento a partir dos campos da interface.

O prompt descreve APENAS o movimento. A aparência do personagem vem da imagem
de referência (primeiro quadro do vídeo), então nunca redescrevemos rosto,
roupa ou cores aqui, só reforçamos que nada disso deve mudar.
"""

CAMERA_OPTIONS = {
    "Câmera fixa": "static camera, no camera movement",
    "Zoom in lento": "slow camera push-in toward the character",
    "Zoom out lento": "slow camera pull-back revealing more of the scene",
    "Panorâmica para a esquerda": "smooth camera pan to the left",
    "Panorâmica para a direita": "smooth camera pan to the right",
    "Segue o personagem": "camera smoothly follows the character as it moves",
    "Câmera orbitando": "camera slowly orbits around the character",
}

CONSISTENCY_SUFFIX = (
    "Keep the character exactly identical to the reference image: same face, eyes, "
    "hair or fur, outfit, colors and body proportions. Same 3D animated art style. "
    "Vertical 9:16 framing."
)

# Só é enviado para modelos que aceitam negative_prompt.
NEGATIVE_PROMPT = (
    "different character, changed outfit, changed colors, deformed face, "
    "extra limbs, extra fingers, text, watermark, blur, low quality"
)


def build_prompt(
    action: str,
    body: str = "",
    expression: str = "",
    camera: str = "Câmera fixa",
    scenario: str = "",
) -> str:
    """Junta os campos em um único prompt. Levanta ValueError sem ação."""
    action = (action or "").strip()
    if not action:
        raise ValueError("Escreva a ação que deve ser animada.")
    if camera not in CAMERA_OPTIONS:
        raise ValueError(f"Movimento de câmera desconhecido: {camera!r}")

    parts = [f"Action: {action}."]
    if (body or "").strip():
        parts.append(f"Body movement: {body.strip()}.")
    if (expression or "").strip():
        parts.append(f"Facial expression: {expression.strip()}.")
    if (scenario or "").strip():
        parts.append(f"Setting: {scenario.strip()}.")
    parts.append(f"Camera: {CAMERA_OPTIONS[camera]}.")
    parts.append(CONSISTENCY_SUFFIX)
    return " ".join(p.replace("..", ".") for p in parts)
