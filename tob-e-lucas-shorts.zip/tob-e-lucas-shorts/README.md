# Tob e Lucas Shorts — gerador de clipes

Organiza a produção de Shorts com o Tob e o Lucas a partir das imagens originais deles
(`assets/personagens/`). A imagem original é o primeiro quadro do vídeo; o prompt descreve só o movimento.

Dois modos (escolha na barra lateral):

| Modo | Quem gera o vídeo | Custo |
|---|---|---|
| **Flow (manual)** — padrão | Você, no site do Flow | Créditos da sua assinatura do Flow |
| **fal.ai · Kling (automático)** | O app, via API | Pago por clipe (precisa de chave) |

## 1. Instalar

```bash
pip install -r requirements.txt
```

Para validar clipes e juntar o vídeo final é preciso ter o `ffmpeg` (inclui o `ffprobe`) instalado.

## 2. Rodar

```bash
streamlit run app.py
```

- **Aba 1 – Nova cena:** escolha o personagem, escreva a ação, movimento do corpo, expressão, câmera, cenário e duração.
- **Aba 2 – Cenas e clipes:** reordene (⬆⬇), apague e use o prompt de cada cena (ou o roteiro completo, com botão de copiar).
- **Aba 3 – Montagem:** junta os clipes, na ordem das cenas, em um único MP4 vertical 1080x1920.

Tudo fica em `output/` (clipes, vídeo final e `scenes.json`).

## Usar pelo iPhone

O app é feito em Python e **não roda dentro do iPhone**. O jeito mais simples é rodá-lo em um computador
(Windows, Mac ou Linux) e usar a tela pelo Safari do iPhone, na mesma rede Wi-Fi:

1. No computador, descompacte o ZIP e rode `streamlit run app.py`.
2. O terminal mostra um **Network URL** (algo como `http://192.168.x.x:8501`). Se ele não aparecer, rode
   `streamlit run app.py --server.address 0.0.0.0`. Abra esse endereço no Safari do iPhone.
3. Gere os clipes no site do Flow (também pelo Safari), salve o vídeo no iPhone e envie pelo campo de upload da cena.

Os clipes e o vídeo final ficam salvos no computador, na pasta `output/`.

## Modo Flow (manual)

O Flow não tem API oficial, então a geração é feita por você no site. O fluxo, por cena:

1. No Flow, abra um projeto. No campo de prompt, escolha **Video → Frames** e arraste a imagem da cena
   para **Add start frame**.
2. Escolha o formato vertical (9:16), se estiver disponível na sua conta. A ajuda do Flow não lista os formatos.
3. Cole o prompt da cena (copie no app) e gere.
4. Baixe o melhor resultado e envie no campo **Clipe baixado do Flow**, na cena. Clique em **Salvar clipe nesta cena**.

O app avisa se o clipe enviado não for vertical 9:16 ou se o arquivo não for um vídeo. Os nomes dos menus do Flow podem mudar.

Não usamos ferramentas que automatizam o navegador do Flow: elas violam os termos do Google e arriscam sua conta.

## Modo fal.ai · Kling (automático, opcional)

1. Crie conta em https://fal.ai e adicione créditos.
2. Crie uma chave em https://fal.ai/dashboard/keys.
3. Copie `.env.example` para `.env` e cole a chave: `FAL_KEY=sua_chave`.

Sem a chave, o app avisa "serviço não conectado" e **não gera nada** (nunca simula vídeo).

| Modelo | Duração | Estimativa (confira em fal.ai/pricing) |
|---|---|---|
| Kling 3.0 Standard (padrão) | 3–15 s | ~US$ 0,084/s (comparativos de terceiros) |
| Kling 2.1 Standard | 5 ou 10 s | US$ 0,25 (5 s) / US$ 0,50 (10 s), conforme a página do modelo |

## Dicas para manter os personagens iguais

- Use a imagem original como quadro inicial e clipes curtos. Quanto mais longo, maior a chance de o rosto "derivar".
- Descreva só movimento. Não redescreva roupa, cor ou rosto.
- O cenário parte do fundo da imagem original. Para um cenário muito diferente, use outra imagem base do mesmo personagem.
- Gere, assista e refaça: cada tentativa gasta créditos.

## Trocar ou adicionar serviço de API

Crie um arquivo em `src/providers/` com uma classe que implemente `Provider.generate` (veja `base.py` e `fal_kling.py`)
e use-a no `app.py`. O Veo tem API oficial na Gemini API e pode ser adicionado assim.

## Testes

```bash
pytest
```

Cobrem prompt, argumentos da API, custos, lista de cenas, erro sem chave e a montagem (esta exige ffmpeg). Não chamam APIs.
